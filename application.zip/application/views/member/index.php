<div class="wrapper">
  <div class="parallax filter-gradient green" data-color="blue">
    <div class="container">
      <div class="row">
        <div class="col-md-7  hidden-xs">
          <div class="parallax-image">
            <img src="https://covid.tuf.edu.pk/asset/Images/1.png" />
          </div>
        </div>
        <div class="col-md-5">
          <div class="description text-center">
            <h2>Website Diagnosa COVID 19</h2>
            <br>
            <h5>Selamat Datang, <?= $user['nama_user']; ?></h5>
            <div class="buttons">
              <a href="<?= base_url('member/diagnosa'); ?>" class="btn btn-fill btn-neutral">
                <i class="fa fa-play"></i> Mulai Diagnosa
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>