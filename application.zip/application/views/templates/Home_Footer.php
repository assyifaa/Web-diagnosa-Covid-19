<footer class="footer">
  <div class="container">
    <div class="copyright">
      &copy; Website Diagnosa COVID 19
    </div>
  </div>
</footer>
</div>



</body>

<script src="<?= base_url('assets2'); ?>/js/jquery-3.1.1.min.js" type="text/javascript"></script>
<script src="<?= base_url('assets2'); ?>/js/jquery.easing.1.3.js" type="text/javascript"></script>
<script src="<?= base_url('assets2'); ?>/js/bootstrap.js" type="text/javascript"></script>
<script src="<?= base_url('assets2'); ?>/js/awesome-landing-page.js" type="text/javascript"></script>
<script src="<?= base_url('assets2'); ?>/js/script.js" type="text/javascript">
</script>

</html>