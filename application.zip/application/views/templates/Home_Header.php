<!doctype html>
<html lang="en" id="home">

<head>
  <meta charset="utf-8" />
  <link rel="icon" type="image/png" href="<?= base_url('assets2'); ?>/img/favicon2.ico">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>Website Diagnosa COVID 19</title>
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
  <meta name="viewport" content="width=device-width" />

  <link href="<?= base_url('assets2'); ?>/css/bootstrap.css" rel="stylesheet" />
  <link href="<?= base_url('assets2'); ?>/css/landing-page.css" rel="stylesheet" />

  <!--     Fonts and icons     -->
  <link href="<?= base_url('assets2'); ?>/css/font-awesome.min.css" rel="stylesheet">
  <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400,300' rel='stylesheet' type='text/css'>
  <link href="<?= base_url('assets2'); ?>/css/pe-icon-7-stroke.css" rel="stylesheet" />
</head>

<body class="landing-page landing-page2">