<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title><?= $judul; ?></title>
  <link href="<?= base_url('assetsdiagnosa'); ?>/css/styles.css" rel="stylesheet">
</head>

<body>