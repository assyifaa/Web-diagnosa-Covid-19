-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 10, 2021 at 11:40 AM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 7.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `covid`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_gejala`
--

CREATE TABLE `tbl_gejala` (
  `id_gejala` int(11) NOT NULL,
  `kode_gejala` char(3) NOT NULL,
  `nama_gejala` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_gejala`
--

INSERT INTO `tbl_gejala` (`id_gejala`, `kode_gejala`, `nama_gejala`) VALUES
(1, 'G01', 'Demam (Lebih dari 38%)'),
(2, 'G02', 'Sesak Nafas'),
(3, 'G03', 'Kejang Kejang'),
(4, 'G04', 'Diare dan Mual'),
(5, 'G05', 'Kelelahan'),
(6, 'G06', 'Infeksi Saluran Pernafasan'),
(7, 'G07', 'Rasa Kedinginan dan Nyeri Otot'),
(8, 'G08', 'Pegal - Pegal'),
(9, 'G09', 'Keadaan Bingung'),
(10, 'G10', 'Kehilangan Indra Penciuman dan Rasa'),
(11, 'G11', 'Kulit Terasa Terbakar / Tersengat Listrik'),
(12, 'G12', 'Sakit Kepala dan Pusing'),
(13, 'G13', 'Batuk Tidak Berdahak');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_hasil_diagnosa`
--

CREATE TABLE `tbl_hasil_diagnosa` (
  `id_hasil` int(11) NOT NULL,
  `hasil_probabilitas` float NOT NULL,
  `nama_kerusakan` varchar(100) NOT NULL,
  `nama_user` varchar(25) NOT NULL,
  `solusi` text NOT NULL,
  `waktu` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_hasil_diagnosa`
--

INSERT INTO `tbl_hasil_diagnosa` (`id_hasil`, `hasil_probabilitas`, `nama_kerusakan`, `nama_user`, `solusi`, `waktu`) VALUES
(33, 83, 'Flu Biasa', 'taufik', '', 1623303181),
(34, 71, 'Flu Biasa', 'taufik', '', 1623303197),
(35, 100, 'Flu Biasa', 'taufik', '', 1623303212),
(36, 0, 'Covid 19', 'taufik', '', 1623303249),
(37, 0, 'Covid 19', 'taufik', '', 1623303262),
(38, 0, 'Covid 19', 'taufik', '', 1623303276),
(39, 71, 'Flu Biasa', 'taufik', '', 1623303286),
(40, 0, 'Covid 19', 'taufik', '', 1623303382),
(41, 0, 'Covid 19', 'taufik', '', 1623306510),
(42, 51, 'Flu Biasa', 'taufik', '', 1623306874),
(43, 0, 'Covid 19', 'taufik', '', 1623306986),
(44, 30, 'Flu Biasa', 'taufik', '', 1623307066),
(45, 0, 'Covid 19', 'taufik', '', 1623317657),
(46, 51, 'Flu Biasa', 'taufik', '', 1623317708),
(47, 0, 'Covid 19', 'taufik', '', 1623317761),
(48, 51, 'Flu Biasa', 'taufik', '', 1623317778),
(49, 83, 'Flu Biasa', 'taufik', '', 1623317996);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_kerusakan`
--

CREATE TABLE `tbl_kerusakan` (
  `id_kerusakan` int(11) NOT NULL,
  `kode_kerusakan` char(3) NOT NULL,
  `nama_kerusakan` varchar(100) NOT NULL,
  `solusi` text NOT NULL,
  `probabilitas` float NOT NULL,
  `gambar` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_kerusakan`
--

INSERT INTO `tbl_kerusakan` (`id_kerusakan`, `kode_kerusakan`, `nama_kerusakan`, `solusi`, `probabilitas`, `gambar`) VALUES
(1, 'K01', 'Covid 19', '', 0.1, 'IC_Power2.jpg'),
(2, 'K02', 'Flu Biasa', '', 0.2, 'IC_Vga2.jpg'),
(3, 'K03', 'Flu Biasa', '', 0.2, 'screen_inverter4.jpg'),
(4, 'K04', 'Flu Biasa', '', 0.2, 'lcd6.jpg'),
(5, 'K05', 'Flu Biasa', '', 0.2, 'keyboard5.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pengetahuan`
--

CREATE TABLE `tbl_pengetahuan` (
  `id` int(11) NOT NULL,
  `id_kerusakan` int(11) NOT NULL,
  `id_gejala` int(11) NOT NULL,
  `probabilitas` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_pengetahuan`
--

INSERT INTO `tbl_pengetahuan` (`id`, `id_kerusakan`, `id_gejala`, `probabilitas`) VALUES
(1, 1, 1, 0.2),
(2, 1, 2, 0.5),
(3, 1, 3, 1),
(5, 1, 4, 0.5),
(6, 1, 5, 0),
(7, 1, 6, 0),
(8, 1, 7, 0),
(9, 1, 8, 0),
(10, 1, 9, 0),
(11, 1, 10, 0),
(12, 1, 11, 0),
(13, 1, 12, 0),
(14, 1, 13, 0),
(15, 2, 1, 0.5),
(16, 2, 2, 0.5),
(17, 2, 3, 0.5),
(18, 2, 4, 0),
(19, 2, 5, 1),
(20, 2, 6, 0.5),
(21, 2, 7, 0.5),
(22, 2, 8, 0),
(23, 2, 9, 0),
(24, 2, 10, 0),
(25, 2, 11, 0),
(26, 2, 12, 0),
(27, 2, 13, 0.5),
(28, 3, 1, 1),
(29, 3, 2, 0),
(30, 3, 3, 0),
(31, 3, 4, 0),
(32, 3, 5, 1),
(33, 3, 6, 0),
(34, 3, 7, 1),
(35, 3, 8, 1),
(36, 3, 9, 0),
(37, 3, 10, 0),
(38, 3, 11, 0),
(39, 3, 12, 0),
(40, 3, 13, 0),
(41, 4, 1, 0.33),
(42, 4, 2, 0),
(43, 4, 3, 0),
(44, 4, 4, 0),
(45, 4, 5, 0.33),
(46, 4, 6, 0),
(47, 4, 7, 0),
(48, 4, 8, 0.33),
(49, 4, 9, 1),
(50, 4, 10, 1),
(51, 4, 11, 0.33),
(52, 4, 12, 0),
(53, 4, 13, 0),
(54, 5, 1, 0),
(55, 5, 2, 0),
(56, 5, 3, 0),
(57, 5, 4, 0),
(58, 5, 5, 1),
(59, 5, 6, 0),
(60, 5, 7, 0),
(61, 5, 8, 0),
(62, 5, 9, 0),
(63, 5, 10, 0),
(64, 5, 11, 0),
(65, 5, 12, 0.5),
(66, 5, 13, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id_user` int(11) NOT NULL,
  `nama_user` varchar(25) NOT NULL,
  `username` varchar(25) NOT NULL,
  `image` varchar(256) NOT NULL,
  `password` varchar(256) NOT NULL,
  `role_id` int(11) NOT NULL,
  `date_created` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id_user`, `nama_user`, `username`, `image`, `password`, `role_id`, `date_created`) VALUES
(12, 'taufik', 'taufik', 'default.jpg', 'taufik', 2, 1623299235);

-- --------------------------------------------------------

--
-- Table structure for table `tmp_final`
--

CREATE TABLE `tmp_final` (
  `id` int(11) NOT NULL,
  `id_gejala` int(11) NOT NULL,
  `id_kerusakan` int(11) NOT NULL,
  `probabilitas` float NOT NULL,
  `hasil_probabilitas` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tmp_final`
--

INSERT INTO `tmp_final` (`id`, `id_gejala`, `id_kerusakan`, `probabilitas`, `hasil_probabilitas`) VALUES
(1, 1, 1, 0.2, 0.166667),
(2, 1, 2, 0.5, 0.833333),
(3, 1, 3, 1, 0),
(4, 1, 4, 0.33, 0),
(5, 1, 5, 0, 0),
(6, 2, 1, 0.5, 0.166667),
(7, 2, 2, 0.5, 0.833333),
(8, 2, 3, 0, 0),
(9, 2, 4, 0, 0),
(10, 2, 5, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tmp_gejala`
--

CREATE TABLE `tmp_gejala` (
  `id_user` int(11) NOT NULL,
  `id_gejala` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tmp_gejala`
--

INSERT INTO `tmp_gejala` (`id_user`, `id_gejala`) VALUES
(12, 1),
(12, 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_gejala`
--
ALTER TABLE `tbl_gejala`
  ADD PRIMARY KEY (`id_gejala`);

--
-- Indexes for table `tbl_hasil_diagnosa`
--
ALTER TABLE `tbl_hasil_diagnosa`
  ADD PRIMARY KEY (`id_hasil`);

--
-- Indexes for table `tbl_kerusakan`
--
ALTER TABLE `tbl_kerusakan`
  ADD PRIMARY KEY (`id_kerusakan`);

--
-- Indexes for table `tbl_pengetahuan`
--
ALTER TABLE `tbl_pengetahuan`
  ADD PRIMARY KEY (`id`),
  ADD KEY `kode_gejala` (`id_gejala`),
  ADD KEY `id_kerusakan` (`id_kerusakan`);

--
-- Indexes for table `tmp_final`
--
ALTER TABLE `tmp_final`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_gejala`
--
ALTER TABLE `tbl_gejala`
  MODIFY `id_gejala` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `tbl_hasil_diagnosa`
--
ALTER TABLE `tbl_hasil_diagnosa`
  MODIFY `id_hasil` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `tbl_kerusakan`
--
ALTER TABLE `tbl_kerusakan`
  MODIFY `id_kerusakan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tbl_pengetahuan`
--
ALTER TABLE `tbl_pengetahuan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;

--
-- AUTO_INCREMENT for table `tmp_final`
--
ALTER TABLE `tmp_final`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_pengetahuan`
--
ALTER TABLE `tbl_pengetahuan`
  ADD CONSTRAINT `tbl_pengetahuan_ibfk_1` FOREIGN KEY (`id_kerusakan`) REFERENCES `tbl_kerusakan` (`id_kerusakan`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
